export type GradingScaleType = '5.0' | '4.0';

export interface GradeDefinition {
  letter: string;
  points: number;
  description: string;
  minScore?: number;
}

export interface DegreeClassification {
  label: string;
  minCgpa: number;
  maxCgpa: number;
  badgeColor: string; // Tailwind color class
  textColor: string;
}

export interface Course {
  id: string;
  code: string;
  title: string;
  units: number;
  grade: string;
}

export interface Semester {
  id: string;
  name: string; // e.g. "Year 3, 1st Semester"
  level: string; // e.g. "300L"
  courses: Course[];
}

export interface TargetGoalConfig {
  targetCgpa: number;
  currentCgpa: number;
  completedUnits: number;
  remainingUnits: number;
  gradingScale: GradingScaleType;
}

export interface GradeRecipe {
  title: string;
  description: string;
  recipeType: 'optimum' | 'balanced' | 'minimum_risk';
  breakdown: {
    letter: string;
    points: number;
    units: number;
    courseCountApprox: number;
  }[];
  projectedSemesterGpa: number;
  projectedFinalCgpa: number;
  feasibility: 'easily_achievable' | 'moderate' | 'challenging' | 'impossible';
}

export interface SimulationResult {
  maxPossibleCgpa: number;
  minPossibleCgpa: number;
  isFeasible: boolean;
  requiredGpaForRemaining: number;
  totalUnitsOverall: number;
  currentTotalQualityPoints: number;
  targetClassification: string;
  currentClassification: string;
  recipes: GradeRecipe[];
}
