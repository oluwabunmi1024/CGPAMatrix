import React from 'react';
import { Target, Calculator, SlidersHorizontal, Sparkles, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

interface MobileBottomNavProps {
  activeTab: 'overview' | 'forecaster' | 'coursework' | 'sandbox';
  setActiveTab: (tab: 'overview' | 'forecaster' | 'coursework' | 'sandbox') => void;
  onOpenMethodology: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenMethodology,
}) => {
  const navItems: Array<{
    id: 'overview' | 'forecaster' | 'coursework' | 'sandbox';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'overview', label: 'Specs', icon: Sparkles },
    { id: 'forecaster', label: 'Forecast', icon: Target },
    { id: 'coursework', label: 'Courses', icon: Calculator },
    { id: 'sandbox', label: 'Stress Test', icon: SlidersHorizontal },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-neutral-900/95 backdrop-blur-lg border-t border-neutral-800/90 px-2 py-1.5 md:hidden shadow-[0_-8px_24px_rgba(0,0,0,0.5)]">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-3 min-w-[64px] rounded-xl transition-all cursor-pointer ${
                isActive ? 'text-emerald-400 font-bold' : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeMobileTabGlow"
                  className="absolute inset-0 bg-emerald-500/10 rounded-xl border border-emerald-500/20"
                  transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
                />
              )}
              <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 text-emerald-400' : ''}`} />
              <span className="text-[10px] mt-1 tracking-tight leading-none">{item.label}</span>
            </button>
          );
        })}

        <button
          type="button"
          onClick={onOpenMethodology}
          className="flex flex-col items-center justify-center py-1.5 px-3 min-w-[64px] rounded-xl text-neutral-400 hover:text-neutral-200 transition-all cursor-pointer"
        >
          <BookOpen className="w-5 h-5" />
          <span className="text-[10px] mt-1 tracking-tight leading-none">Math</span>
        </button>
      </div>
    </nav>
  );
};
