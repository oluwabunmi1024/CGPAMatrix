import { useState, useEffect, useId } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  GradingScaleType,
  Course,
  SimulationResult,
} from '../../types/gradecraft';
import {
  GRADES_5_0,
  GRADES_4_0,
  CLASSIFICATIONS_5_0,
  CLASSIFICATIONS_4_0,
  calculateSemesterGPA,
  simulateTargetGoal,
  getClassification,
  SAMPLE_SEMESTERS,
} from '../../utils/gradecraftLogic';
import { MethodologyModal } from './MethodologyModal';
import { ProjectOverviewSection } from './ProjectOverviewSection';
import { MobileBottomNav } from './MobileBottomNav';
import { MobileSummaryHeader } from './MobileSummaryHeader';
import {
  GraduationCap,
  Target,
  Calculator,
  SlidersHorizontal,
  Plus,
  Trash2,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  BookOpen,
  Award,
  ArrowRight,
  ShieldCheck,
  FileText,
} from 'lucide-react';

export function GradeCraftApp() {
  // Grading scale: 5.0 (Nigerian/UK) or 4.0 (US/Canada)
  const [scale, setScale] = useState<GradingScaleType>('5.0');

  // Active view tab
  const [activeTab, setActiveTab] = useState<'overview' | 'forecaster' | 'coursework' | 'sandbox'>('overview');

  // Methodology and Specification Modal state
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);

  // Forecaster Inputs
  const [currentCgpa, setCurrentCgpa] = useState<number>(3.84);
  const [completedUnits, setCompletedUnits] = useState<number>(76);
  const [targetCgpa, setTargetCgpa] = useState<number>(4.50);
  const [remainingUnits, setRemainingUnits] = useState<number>(36);

  // Active Semester Courses for Tab 2
  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem('gradecraft_courses');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return SAMPLE_SEMESTERS;
      }
    }
    return SAMPLE_SEMESTERS;
  });

  // What-If Sandbox test GPA
  const [sandboxGpa, setSandboxGpa] = useState<number>(4.60);

  // Unique IDs for form controls
  const currentCgpaInputId = useId();
  const completedUnitsInputId = useId();
  const targetCgpaInputId = useId();
  const remainingUnitsInputId = useId();
  const sandboxGpaSliderId = useId();

  // Save courses to localStorage
  useEffect(() => {
    localStorage.setItem('gradecraft_courses', JSON.stringify(courses));
  }, [courses]);

  // Derived simulation for forecaster
  const simulation: SimulationResult = simulateTargetGoal(
    currentCgpa,
    completedUnits,
    targetCgpa,
    remainingUnits,
    scale
  );

  // Derived calculations for current semester coursework
  const semesterStats = calculateSemesterGPA(courses, scale);

  // Projected overall CGPA when combining current + semester coursework
  const combinedTotalUnits = completedUnits + semesterStats.totalUnits;
  const combinedQualityPoints = (currentCgpa * completedUnits) + semesterStats.totalPoints;
  const projectedCombinedCgpa = combinedTotalUnits > 0
    ? Number((combinedQualityPoints / combinedTotalUnits).toFixed(2))
    : currentCgpa;

  // Sandbox projected outcome
  const sandboxTotalUnits = completedUnits + remainingUnits;
  const sandboxProjectedCgpa = sandboxTotalUnits > 0
    ? Number(((currentCgpa * completedUnits + sandboxGpa * remainingUnits) / sandboxTotalUnits).toFixed(2))
    : currentCgpa;

  const currentClass = getClassification(currentCgpa, scale);
  const targetClass = getClassification(targetCgpa, scale);
  const sandboxClass = getClassification(sandboxProjectedCgpa, scale);

  const availableGrades = scale === '5.0' ? GRADES_5_0 : GRADES_4_0;
  const classifications = scale === '5.0' ? CLASSIFICATIONS_5_0 : CLASSIFICATIONS_4_0;

  // Add course handler
  const handleAddCourse = () => {
    const newCourse: Course = {
      id: String(Date.now()),
      code: `CSC ${300 + courses.length * 2}`,
      title: 'New Elective / Core Unit',
      units: 3,
      grade: 'A',
    };
    setCourses([...courses, newCourse]);
  };

  // Remove course handler
  const handleRemoveCourse = (id: string) => {
    setCourses(courses.filter((c) => c.id !== id));
  };

  // Update course field
  const handleUpdateCourse = (id: string, field: keyof Course, value: string | number) => {
    setCourses(
      courses.map((c) => {
        if (c.id === id) {
          return { ...c, [field]: value };
        }
        return c;
      })
    );
  };

  // Load sample student profiles
  const handleLoadSample = (scenario: 'first_class_push' | 'freshman' | 'final_lap') => {
    if (scenario === 'first_class_push') {
      setScale('5.0');
      setCurrentCgpa(4.18);
      setCompletedUnits(82);
      setTargetCgpa(4.50);
      setRemainingUnits(38);
      setSandboxGpa(4.80);
    } else if (scenario === 'final_lap') {
      setScale('5.0');
      setCurrentCgpa(3.42);
      setCompletedUnits(110);
      setTargetCgpa(3.50);
      setRemainingUnits(20);
      setSandboxGpa(4.20);
    } else {
      setScale('5.0');
      setCurrentCgpa(4.65);
      setCompletedUnits(34);
      setTargetCgpa(4.75);
      setRemainingUnits(86);
      setSandboxGpa(4.70);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col selection:bg-emerald-500 selection:text-white">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-neutral-900/90 backdrop-blur-md border-b border-neutral-800 px-4 lg:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white">CGPAMatrix</span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  Target Forecaster
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Predictive CGPA Simulator &amp; Target Degree Planner
              </p>
            </div>
          </div>

          {/* Quick Controls */}
          <div className="flex items-center gap-3">
            {/* Scale Selector */}
            <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded-xl p-1 text-xs">
              <button
                type="button"
                onClick={() => {
                  setScale('5.0');
                  if (targetCgpa < 3.0) setTargetCgpa(4.50);
                }}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg font-medium transition-all ${
                  scale === '5.0'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <span className="sm:hidden">5.0 Scale</span>
                <span className="hidden sm:inline">5.0 Scale (Nigeria / UK)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setScale('4.0');
                  if (targetCgpa > 4.0) setTargetCgpa(3.80);
                  if (currentCgpa > 4.0) setCurrentCgpa(3.40);
                }}
                className={`px-2.5 sm:px-3 py-1.5 rounded-lg font-medium transition-all ${
                  scale === '4.0'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                <span className="sm:hidden">4.0 Scale</span>
                <span className="hidden sm:inline">4.0 Scale (US / Global)</span>
              </button>
            </div>

            {/* Engineering Methodology Button */}
            <button
              type="button"
              onClick={() => setIsMethodologyOpen(true)}
              className="px-3.5 py-1.5 rounded-xl border border-neutral-800 bg-neutral-900 hover:bg-neutral-800 text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Engineering Specs</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 flex flex-col gap-6 pb-24 md:pb-8">
        {/* Mobile Quick Summary Header */}
        <MobileSummaryHeader
          simulation={simulation}
          currentCgpa={currentCgpa}
          targetCgpa={targetCgpa}
          scale={scale}
          onNavigateForecaster={() => setActiveTab('forecaster')}
        />

        {/* Navigation Tabs & Quick Presets */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-neutral-800 pb-4">
          <div className="hidden md:flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('overview')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Project Overview &amp; Specs</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('forecaster')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'forecaster'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              <Target className="w-3.5 h-3.5" />
              <span>Reverse Target Simulator</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('coursework')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'coursework'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Semester Coursework &amp; Live GPA</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('sandbox')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'sandbox'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                  : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>&quot;What-If&quot; Stress Test</span>
            </button>
          </div>

          {/* Quick Scenario Fillers */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-neutral-500 hidden sm:inline">Try Preset:</span>
            <button
              type="button"
              onClick={() => handleLoadSample('first_class_push')}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors"
            >
              First Class Push (4.18 → 4.50)
            </button>
            <button
              type="button"
              onClick={() => handleLoadSample('final_lap')}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 transition-colors"
            >
              2:1 Clutch (3.42 → 3.50)
            </button>
          </div>
        </div>

        {/* Tab Views with Animated Transitions */}
        <AnimatePresence mode="wait">
          {/* TAB 0: PROJECT OVERVIEW & DETAILED EXPLANATION */}
          {activeTab === 'overview' && (
            <motion.div
              key="tab-overview"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
            >
              <ProjectOverviewSection
                scale={scale}
                onOpenModal={() => setIsMethodologyOpen(true)}
                onExploreForecaster={() => setActiveTab('forecaster')}
              />
            </motion.div>
          )}

          {/* TAB 1: REVERSE TARGET SIMULATOR */}
          {activeTab === 'forecaster' && (
            <motion.div
              key="tab-forecaster"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6"
            >
              {/* Input Column */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              <div className="bg-neutral-900/70 border border-neutral-800 rounded-2xl p-5 md:p-6 flex flex-col gap-5 shadow-sm">
                <div className="flex items-center justify-between">
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Target className="w-4 h-4 text-emerald-400" />
                    Academic Standing & Target
                  </h2>
                  <span className="text-[11px] text-neutral-400 font-mono">
                    {scale === '5.0' ? 'Max 5.00' : 'Max 4.00'}
                  </span>
                </div>

                {/* Current CGPA */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor={currentCgpaInputId} className="text-neutral-300 font-medium">Current CGPA</label>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${currentClass.badgeColor}`}>
                      {currentClass.label}
                    </span>
                  </div>
                  <input
                    id={currentCgpaInputId}
                    type="number"
                    step="0.01"
                    min="0"
                    max={scale === '5.0' ? '5.0' : '4.0'}
                    value={currentCgpa}
                    onChange={(e) => setCurrentCgpa(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>

                {/* Completed Units */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor={completedUnitsInputId} className="text-neutral-300 font-medium">Credit Units Completed So Far</label>
                    <span className="text-neutral-500 font-mono text-[11px]">e.g. 76 units</span>
                  </div>
                  <input
                    id={completedUnitsInputId}
                    type="number"
                    min="0"
                    max="300"
                    value={completedUnits}
                    onChange={(e) => setCompletedUnits(parseInt(e.target.value, 10) || 0)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>

                <div className="h-px bg-neutral-800" />

                {/* Target CGPA */}
                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor={targetCgpaInputId} className="text-neutral-300 font-medium">Desired Graduating Target CGPA</label>
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${targetClass.badgeColor}`}>
                      {targetClass.label}
                    </span>
                  </div>

                  {/* Target Presets */}
                  <div className="grid grid-cols-2 gap-2">
                    {classifications.slice(0, 2).map((c) => (
                      <button
                        key={c.label}
                        type="button"
                        onClick={() => setTargetCgpa(c.minCgpa)}
                        className={`px-3 py-1.5 rounded-lg border text-xs text-left transition-all ${
                          Math.abs(targetCgpa - c.minCgpa) < 0.05
                            ? 'border-emerald-500 bg-emerald-500/10 text-emerald-300 font-medium'
                            : 'border-neutral-800 bg-neutral-950 hover:bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        <div className="font-semibold text-white">{c.minCgpa.toFixed(2)}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.label}</div>
                      </button>
                    ))}
                  </div>

                  <input
                    id={targetCgpaInputId}
                    type="number"
                    step="0.01"
                    min="0"
                    max={scale === '5.0' ? '5.0' : '4.0'}
                    value={targetCgpa}
                    onChange={(e) => setTargetCgpa(parseFloat(e.target.value) || 0)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>

                {/* Remaining Credit Units */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <label htmlFor={remainingUnitsInputId} className="text-neutral-300 font-medium">Remaining Units Until Graduation</label>
                    <span className="text-neutral-500 font-mono text-[11px]">e.g. 2 semesters ~ 36 units</span>
                  </div>
                  <input
                    id={remainingUnitsInputId}
                    type="number"
                    min="1"
                    max="150"
                    value={remainingUnits}
                    onChange={(e) => setRemainingUnits(parseInt(e.target.value, 10) || 1)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Results & Grade Recipe Column */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              {/* Feasibility Summary Banner */}
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className={`rounded-2xl p-6 border transition-all ${
                  simulation.isFeasible
                    ? 'bg-gradient-to-br from-emerald-950/40 via-neutral-900 to-neutral-900 border-emerald-500/30'
                    : 'bg-gradient-to-br from-rose-950/40 via-neutral-900 to-neutral-900 border-rose-500/30'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${
                        simulation.isFeasible
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {simulation.isFeasible ? (
                        <CheckCircle2 className="w-6 h-6" />
                      ) : (
                        <XCircle className="w-6 h-6" />
                      )}
                    </div>
                    <div>
                      <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                        {simulation.isFeasible ? 'Target Achievable' : 'Mathematical Ceiling Exceeded'}
                      </div>
                      <h3 className="text-lg font-bold text-white mt-0.5">
                        {simulation.isFeasible
                          ? `Required GPA: ${simulation.requiredGpaForRemaining.toFixed(2)} in remaining units`
                          : `Maximum Possible CGPA: ${simulation.maxPossibleCgpa.toFixed(2)}`}
                      </h3>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[11px] text-neutral-400">Total Program Weight</div>
                    <div className="text-base font-bold font-mono text-white">
                      {simulation.totalUnitsOverall} Units
                    </div>
                  </div>
                </div>

                {/* Explanation text */}
                <p className="text-xs text-neutral-300 mt-4 leading-relaxed">
                  {simulation.isFeasible ? (
                    <>
                      To graduate with <strong className="text-white">{targetCgpa.toFixed(2)} ({simulation.targetClassification})</strong>, you need to earn at least{' '}
                      <strong className="text-emerald-400">{simulation.requiredGpaForRemaining.toFixed(2)} GPA</strong> across your final {remainingUnits} credit units.
                    </>
                  ) : (
                    <>
                      Even if you earn <strong className="text-white">straight A&apos;s (5.0 GPA)</strong> across all remaining {remainingUnits} credit units, your graduating CGPA will top out at{' '}
                      <strong className="text-rose-400">{simulation.maxPossibleCgpa.toFixed(2)}</strong> due to previously completed units. Consider adjusting your goal to <strong className="text-white">{simulation.maxPossibleCgpa.toFixed(2)}</strong>.
                    </>
                  )}
                </p>

                {/* Key Metrics Bar */}
                <div className="grid grid-cols-3 gap-3 mt-5 pt-4 border-t border-neutral-800">
                  <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/80">
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Current CGPA</div>
                    <div className="text-base font-bold font-mono text-white mt-0.5">
                      {currentCgpa.toFixed(2)}
                    </div>
                  </div>
                  <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/80">
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Target CGPA</div>
                    <div className="text-base font-bold font-mono text-emerald-400 mt-0.5">
                      {targetCgpa.toFixed(2)}
                    </div>
                  </div>
                  <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/80">
                    <div className="text-[10px] uppercase font-bold text-neutral-400">Max Possible</div>
                    <div className="text-base font-bold font-mono text-cyan-400 mt-0.5">
                      {simulation.maxPossibleCgpa.toFixed(2)}
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Recommended Grade Recipes */}
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    Recommended Grade Combinations (Recipes)
                  </h3>
                  <span className="text-xs text-neutral-400">
                    Based on {remainingUnits} credit units
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {simulation.recipes.map((recipe, index) => (
                    <motion.div
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.08 }}
                      key={recipe.title}
                      className="bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 rounded-2xl p-5 flex flex-col gap-4 transition-all hover:bg-neutral-900/80"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-white">{recipe.title}</h4>
                            <span
                              className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full ${
                                recipe.feasibility === 'easily_achievable'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : recipe.feasibility === 'moderate'
                                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                                  : recipe.feasibility === 'challenging'
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              }`}
                            >
                              {recipe.feasibility.replace('_', ' ')}
                            </span>
                          </div>
                          <p className="text-xs text-neutral-400 mt-1">{recipe.description}</p>
                        </div>

                        <div className="text-right">
                          <div className="text-[10px] text-neutral-500 uppercase font-semibold">Yields</div>
                          <div className="text-base font-bold font-mono text-emerald-400">
                            {recipe.projectedFinalCgpa.toFixed(2)} CGPA
                          </div>
                        </div>
                      </div>

                      {/* Grade Breakdown Chips */}
                      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-neutral-800/80">
                        {recipe.breakdown.map((item) => (
                          <div
                            key={item.letter}
                            className="bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-1.5 flex items-center gap-2.5"
                          >
                            <span
                              className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs ${
                                item.letter === 'A'
                                  ? 'bg-emerald-500 text-neutral-950'
                                  : item.letter === 'B'
                                  ? 'bg-blue-500 text-white'
                                  : 'bg-amber-500 text-neutral-950'
                              }`}
                            >
                              {item.letter}
                            </span>
                            <div className="text-xs">
                              <span className="font-semibold text-white">{item.units} Units</span>
                              <span className="text-neutral-500 text-[11px] ml-1.5">
                                (~{item.courseCountApprox} course{item.courseCountApprox !== 1 ? 's' : ''})
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* TAB 2: SEMESTER COURSEWORK & LIVE GPA */}
        {activeTab === 'coursework' && (
          <motion.div
            key="tab-coursework"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
            className="flex flex-col gap-6"
          >
            {/* Realtime Stats Header Card */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 md:p-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <div className="text-[11px] text-neutral-400 uppercase font-bold tracking-wider">Semester Units</div>
                <div className="text-2xl font-bold font-mono text-white mt-1">
                  {semesterStats.totalUnits} <span className="text-xs text-neutral-500 font-sans font-normal">units</span>
                </div>
              </div>
              <div>
                <div className="text-[11px] text-neutral-400 uppercase font-bold tracking-wider">Quality Points</div>
                <div className="text-2xl font-bold font-mono text-white mt-1">
                  {semesterStats.totalPoints} <span className="text-xs text-neutral-500 font-sans font-normal">pts</span>
                </div>
              </div>
              <div>
                <div className="text-[11px] text-emerald-400 uppercase font-bold tracking-wider">Semester GPA</div>
                <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
                  {semesterStats.gpa.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-cyan-400 uppercase font-bold tracking-wider">New Cumulative CGPA</div>
                <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
                  {projectedCombinedCgpa.toFixed(2)}
                </div>
              </div>
            </div>

            {/* Courses Table Container */}
            <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl overflow-hidden">
              <div className="p-4 md:p-5 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-emerald-400" />
                    Current Registered Courses
                  </h3>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Adjust course credit units and grades to see immediate real-time GPA recalculation.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddCourse}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Course</span>
                </button>
              </div>

              {/* Desktop Table View */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-950 text-neutral-400 uppercase text-[10px] font-bold tracking-wider border-b border-neutral-800">
                    <tr>
                      <th className="py-3 px-4">Course Code</th>
                      <th className="py-3 px-4">Course Title</th>
                      <th className="py-3 px-4 w-28">Credit Units</th>
                      <th className="py-3 px-4 w-36">Projected Grade</th>
                      <th className="py-3 px-4 w-28 text-right">Points</th>
                      <th className="py-3 px-4 w-16 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60">
                    {courses.map((course) => {
                      const gradePoints = availableGrades.find((g) => g.letter === course.grade)?.points || 0;
                      const qualityPts = course.units * gradePoints;

                      return (
                        <tr key={course.id} className="hover:bg-neutral-800/30 transition-colors">
                          {/* Code */}
                          <td className="py-3 px-4">
                            <input
                              type="text"
                              value={course.code}
                              onChange={(e) => handleUpdateCourse(course.id, 'code', e.target.value)}
                              className="w-24 bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1 text-xs font-mono font-semibold text-white focus:outline-none focus:border-emerald-500"
                            />
                          </td>

                          {/* Title */}
                          <td className="py-3 px-4">
                            <input
                              type="text"
                              value={course.title}
                              onChange={(e) => handleUpdateCourse(course.id, 'title', e.target.value)}
                              className="w-full bg-neutral-950/60 border border-neutral-800 rounded-lg px-2.5 py-1 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500"
                            />
                          </td>

                          {/* Units */}
                          <td className="py-3 px-4">
                            <select
                              value={course.units}
                              onChange={(e) => handleUpdateCourse(course.id, 'units', parseInt(e.target.value, 10))}
                              className="bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1 text-xs font-mono text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                            >
                              {[1, 2, 3, 4, 5, 6].map((u) => (
                                <option key={u} value={u}>
                                  {u} Unit{u > 1 ? 's' : ''}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* Grade */}
                          <td className="py-3 px-4">
                            <select
                              value={course.grade}
                              onChange={(e) => handleUpdateCourse(course.id, 'grade', e.target.value)}
                              className={`border rounded-lg px-2.5 py-1 text-xs font-bold font-mono focus:outline-none cursor-pointer ${
                                course.grade === 'A'
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                  : course.grade === 'B'
                                  ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                                  : course.grade === 'C'
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                  : 'bg-neutral-800 text-neutral-300 border-neutral-700'
                              }`}
                            >
                              {availableGrades.map((g) => (
                                <option key={g.letter} value={g.letter} className="bg-neutral-900 text-white">
                                  {g.letter} ({g.points.toFixed(1)} pts) - {g.description}
                                </option>
                              ))}
                            </select>
                          </td>

                          {/* Points */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-neutral-300">
                            {qualityPts.toFixed(1)}
                          </td>

                          {/* Action */}
                          <td className="py-3 px-4 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveCourse(course.id)}
                              disabled={courses.length <= 1}
                              className="text-neutral-500 hover:text-rose-400 p-1 rounded-lg transition-colors disabled:opacity-30 cursor-pointer"
                              title="Delete Course"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Mobile Dedicated Course Cards */}
              <div className="md:hidden p-3 divide-y divide-neutral-800/80 flex flex-col gap-3">
                {courses.map((course) => {
                  const gradePoints = availableGrades.find((g) => g.letter === course.grade)?.points || 0;
                  const qualityPts = course.units * gradePoints;

                  return (
                    <motion.div
                      layout
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      key={course.id}
                      className="bg-neutral-950/80 border border-neutral-800/80 rounded-2xl p-4 flex flex-col gap-3 shadow-sm"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <input
                          type="text"
                          value={course.code}
                          onChange={(e) => handleUpdateCourse(course.id, 'code', e.target.value)}
                          placeholder="Code"
                          className="w-28 bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-white focus:outline-none focus:border-emerald-500"
                        />
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] font-mono text-neutral-400">
                            {qualityPts.toFixed(1)} pts
                          </span>
                          <button
                            type="button"
                            onClick={() => handleRemoveCourse(course.id)}
                            disabled={courses.length <= 1}
                            className="p-2 min-h-[44px] min-w-[44px] flex items-center justify-center text-neutral-500 hover:text-rose-400 rounded-lg disabled:opacity-30 transition-colors cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <input
                        type="text"
                        value={course.title}
                        onChange={(e) => handleUpdateCourse(course.id, 'title', e.target.value)}
                        placeholder="Course title"
                        className="w-full bg-neutral-900/60 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500"
                      />

                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div>
                          <label className="text-[10px] uppercase font-bold text-neutral-500 block mb-1">
                            Units
                          </label>
                          <select
                            value={course.units}
                            onChange={(e) => handleUpdateCourse(course.id, 'units', parseInt(e.target.value, 10))}
                            className="w-full min-h-[44px] bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                          >
                            {[1, 2, 3, 4, 5, 6].map((u) => (
                              <option key={u} value={u}>
                                {u} Unit{u > 1 ? 's' : ''}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] uppercase font-bold text-neutral-500 block mb-1">
                            Grade
                          </label>
                          <select
                            value={course.grade}
                            onChange={(e) => handleUpdateCourse(course.id, 'grade', e.target.value)}
                            className={`w-full min-h-[44px] border rounded-xl px-3 py-2 text-xs font-bold font-mono focus:outline-none ${
                              course.grade === 'A'
                                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                : course.grade === 'B'
                                ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                                : course.grade === 'C'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                : 'bg-neutral-800 text-neutral-300 border-neutral-700'
                            }`}
                          >
                            {availableGrades.map((g) => (
                              <option key={g.letter} value={g.letter} className="bg-neutral-900 text-white">
                                {g.letter} ({g.points.toFixed(1)} pts)
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}

        {/* TAB 3: "WHAT-IF" STRESS TEST PLAYGROUND */}
        {activeTab === 'sandbox' && (
          <motion.div
            key="tab-sandbox"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
            className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 md:p-8 flex flex-col gap-6"
          >
            <div>
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
                <h3 className="text-base font-bold text-white">What-If Stress Test Sandbox</h3>
              </div>
              <p className="text-xs text-neutral-400 mt-1">
                Slide your anticipated future semester GPA up or down to observe how resilient your final graduating degree is against grade drops.
              </p>
            </div>

            {/* Slider Control */}
            <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-6 flex flex-col gap-5">
              <div className="flex items-center justify-between">
                <label htmlFor={sandboxGpaSliderId} className="text-xs text-neutral-400 uppercase font-bold tracking-wider">
                  Hypothetical Future GPA (Across {remainingUnits} remaining units)
                </label>
                <span className="text-3xl font-extrabold font-mono text-emerald-400">
                  {sandboxGpa.toFixed(2)}
                </span>
              </div>

              <input
                id={sandboxGpaSliderId}
                type="range"
                min="0"
                max={scale === '5.0' ? 5.0 : 4.0}
                step="0.05"
                value={sandboxGpa}
                onChange={(e) => setSandboxGpa(parseFloat(e.target.value))}
                className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />

              <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono">
                <span>0.00 (Fail)</span>
                <span>2.50 (Pass)</span>
                <span>{scale === '5.0' ? '3.50 (2:1)' : '3.00 (Honours)'}</span>
                <span>{scale === '5.0' ? '4.50 (First Class)' : '3.80 (Summa Cum Laude)'}</span>
                <span>{scale === '5.0' ? '5.00 (Straight A)' : '4.00 (Straight A)'}</span>
              </div>
            </div>

            {/* Outcome Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-neutral-400 uppercase font-bold">Graduating CGPA Outcome</div>
                  <div className="text-3xl font-bold font-mono text-white mt-1">
                    {sandboxProjectedCgpa.toFixed(2)}
                  </div>
                </div>
                <span className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${sandboxClass.badgeColor}`}>
                  {sandboxClass.label}
                </span>
              </div>

              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-neutral-400 uppercase font-bold">Delta vs Current</div>
                  <div
                    className={`text-3xl font-bold font-mono mt-1 ${
                      sandboxProjectedCgpa >= currentCgpa ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {sandboxProjectedCgpa >= currentCgpa ? '+' : ''}
                    {(sandboxProjectedCgpa - currentCgpa).toFixed(2)}
                  </div>
                </div>
                <div className="text-right text-xs text-neutral-400">
                  Total Credits:{' '}
                  <span className="font-mono text-white font-semibold">{sandboxTotalUnits}</span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-900 bg-neutral-950 px-4 py-4 text-center text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span>CGPAMatrix &copy; {new Date().getFullYear()} &bull; Engineered by Otitologbon Oluwabunmi</span>
          </div>

          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setIsMethodologyOpen(true)}
              className="text-emerald-400 hover:text-emerald-300 underline underline-offset-4 flex items-center gap-1 cursor-pointer transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Full Engineering Specification &amp; Math</span>
            </button>
            <span className="flex items-center gap-1.5 text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Runs 100% Client-Side &amp; Offline
            </span>
          </div>
        </div>
      </footer>

      {/* Methodology and Architecture Modal */}
      <MethodologyModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
      />

      {/* Mobile Ergonomic Bottom Navigation Bar */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenMethodology={() => setIsMethodologyOpen(true)}
      />
    </div>
  );
}
