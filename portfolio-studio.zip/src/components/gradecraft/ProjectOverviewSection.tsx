import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  GraduationCap,
  Target,
  Calculator,
  ShieldCheck,
  Cpu,
  Layers,
  Award,
  BookOpen,
  ArrowRight,
  Sparkles,
  ChevronRight,
  TrendingUp,
  FileSpreadsheet,
} from 'lucide-react';

interface ProjectOverviewSectionProps {
  onOpenModal: () => void;
  onExploreForecaster: () => void;
  scale: string;
}

export const ProjectOverviewSection: React.FC<ProjectOverviewSectionProps> = ({
  onOpenModal,
  onExploreForecaster,
  scale,
}) => {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const faqs = [
    {
      q: 'How does CGPAMatrix calculate my required GPA across remaining credits?',
      a: 'CGPAMatrix computes your Cumulative Quality Points (Current CGPA × Units Completed) and determines the Total Quality Points needed to graduate at your target. The difference divided by your remaining credit units reveals your mathematically required semester GPA.',
    },
    {
      q: 'What does "Mathematical Ceiling Exceeded" mean?',
      a: 'If a student has completed e.g. 100 credits with a 3.20 CGPA and only has 20 credits remaining, even earning straight A’s (5.0 GPA) in all 20 units would result in a max CGPA of 3.50. CGPAMatrix protects students from unrealistic assumptions by identifying their true theoretical ceiling.',
    },
    {
      q: 'Are my entered grades stored on an external server or cloud database?',
      a: 'No. CGPAMatrix runs 100% in your browser. All student courses and targets are persisted locally in browser localStorage. No authentication, email address, or network transmission is required.',
    },
  ];

  return (
    <div className="flex flex-col gap-8 my-4">
      {/* Hero Banner with Project Credentials */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-neutral-900 via-neutral-900/90 to-neutral-950 border border-neutral-800 p-6 sm:p-8 lg:p-10 shadow-xl">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-12 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Academic Performance &amp; Degree Strategy Software</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-tight">
            CGPAMatrix: Intelligent Predictive CGPA Simulator &amp; Target Degree Planner
          </h1>

          <p className="text-sm sm:text-base text-neutral-300 mt-4 leading-relaxed">
            A specialized academic modeling engine designed to solve the <strong className="text-white">Reverse Target Deficit Problem</strong>. Unlike traditional GPA calculators that merely record past semester grades, CGPAMatrix runs integer linear partitions to compute the exact minimum combinations of A&apos;s, B&apos;s, and C&apos;s required across remaining credit units to graduate with your target honours class.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-6">
            <button
              type="button"
              onClick={onExploreForecaster}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-600/25 flex items-center gap-2 cursor-pointer"
            >
              <span>Launch Reverse Forecaster</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onOpenModal}
              className="px-4 py-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-semibold transition-colors flex items-center gap-2 cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-emerald-400" />
              <span>Read Mathematical Architecture &amp; Methodology</span>
            </button>
          </div>
        </div>

        {/* Quick Highlights Metrics Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-8 pt-6 border-t border-neutral-800/80">
          <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/60">
            <div className="text-[10px] uppercase font-bold text-neutral-400">Grading Systems</div>
            <div className="text-sm font-bold text-white mt-0.5">5.0 (NIG/UK) &amp; 4.0 (US)</div>
          </div>
          <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/60">
            <div className="text-[10px] uppercase font-bold text-neutral-400">Core Engine</div>
            <div className="text-sm font-bold text-emerald-400 mt-0.5">Reverse Target Partition</div>
          </div>
          <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/60">
            <div className="text-[10px] uppercase font-bold text-neutral-400">Data Persistence</div>
            <div className="text-sm font-bold text-cyan-400 mt-0.5">100% Client-Side Sandbox</div>
          </div>
          <div className="bg-neutral-950/60 rounded-xl p-3 border border-neutral-800/60">
            <div className="text-[10px] uppercase font-bold text-neutral-400">Stress Testing</div>
            <div className="text-sm font-bold text-amber-400 mt-0.5">Realtime Volatility Slider</div>
          </div>
        </div>
      </div>

      {/* Feature Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          whileHover={{ y: -4 }}
          className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mb-4">
              <Target className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1.5">Reverse Target Forecaster</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Provides the exact recipe of required grades. Know whether your desired class (e.g. First Class Honours or 2:1) requires 3 A&apos;s and 2 B&apos;s or straight A&apos;s, eliminating guesswork before exams start.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800/80 text-[11px] font-mono text-emerald-400">
            Linear Deficit Resolution &rarr;
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          whileHover={{ y: -4 }}
          className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center mb-4">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1.5">Interactive Coursework Matrix</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Register active semester courses with real credit units. Watch semester GPA and cumulative CGPA dynamically recompute in milliseconds as you test different letter grade outcomes.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800/80 text-[11px] font-mono text-blue-400">
            Realtime Quality Point Engine &rarr;
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          whileHover={{ y: -4 }}
          className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mb-4">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1.5">What-If Risk Stress Testing</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Simulate high-risk scenarios. Drag the slider to see how resilient your final graduation class is if a tough course drops your semester GPA from 4.80 to 3.70.
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-neutral-800/80 text-[11px] font-mono text-amber-400">
            Boundary Sensitivity Analysis &rarr;
          </div>
        </motion.div>
      </div>

      {/* Frequently Asked Questions */}
      <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6">
        <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-emerald-400" />
          Frequently Asked Questions &amp; Methodologies
        </h3>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = activeFaq === idx;
            return (
              <div
                key={faq.q}
                className="border border-neutral-800/80 rounded-xl bg-neutral-950/60 overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => setActiveFaq(isOpen ? null : idx)}
                  className="w-full text-left px-4 py-3 text-xs font-semibold text-neutral-200 hover:text-white flex items-center justify-between gap-3 cursor-pointer"
                >
                  <span>{faq.q}</span>
                  <ChevronRight
                    className={`w-4 h-4 text-neutral-500 transition-transform ${
                      isOpen ? 'rotate-90 text-emerald-400' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-4 pb-3.5 text-xs text-neutral-400 leading-relaxed border-t border-neutral-800/60 pt-2.5">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
