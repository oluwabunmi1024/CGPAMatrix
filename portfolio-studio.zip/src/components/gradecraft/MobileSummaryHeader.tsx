import React from 'react';
import { Target, CheckCircle2, XCircle, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SimulationResult } from '../../types/gradecraft';

interface MobileSummaryHeaderProps {
  simulation: SimulationResult;
  currentCgpa: number;
  targetCgpa: number;
  scale: string;
  onNavigateForecaster: () => void;
}

export const MobileSummaryHeader: React.FC<MobileSummaryHeaderProps> = ({
  simulation,
  currentCgpa,
  targetCgpa,
  scale,
  onNavigateForecaster,
}) => {
  return (
    <div className="md:hidden w-full bg-neutral-900/80 border border-neutral-800/80 rounded-2xl p-3.5 mb-2 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
              simulation.isFeasible
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
            }`}
          >
            {simulation.isFeasible ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <XCircle className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">
                Target: {targetCgpa.toFixed(2)}
              </span>
              <span className="text-[10px] text-neutral-500">&bull;</span>
              <span className="text-[10px] font-mono text-neutral-300">
                Current: {currentCgpa.toFixed(2)}
              </span>
            </div>
            <div className="text-xs font-bold text-white mt-0.5">
              {simulation.isFeasible
                ? `Needs ${simulation.requiredGpaForRemaining.toFixed(2)} GPA`
                : `Max Ceiling: ${simulation.maxPossibleCgpa.toFixed(2)}`}
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onNavigateForecaster}
          className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
        >
          <span>Adjust</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
