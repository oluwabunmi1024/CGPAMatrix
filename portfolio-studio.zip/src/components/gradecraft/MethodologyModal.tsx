import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BookOpen,
  Code2,
  Cpu,
  Calculator,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  X,
  Target,
  GraduationCap,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface MethodologyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MethodologyModal: React.FC<MethodologyModalProps> = ({ isOpen, onClose }) => {
  const [activeSection, setActiveSection] = useState<'overview' | 'math' | 'architecture' | 'guide'>('overview');

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-neutral-950/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-4xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-neutral-100"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-neutral-800 bg-neutral-950/40">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white">CGPAMatrix Academic Intelligence</h3>
                  <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Full Specification
                  </span>
                </div>
                <p className="text-xs text-neutral-400">
                  Mathematical modeling, reverse target algorithms, and architectural specifications
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 px-6 py-3 border-b border-neutral-800 bg-neutral-950/60 overflow-x-auto text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveSection('overview')}
              className={`px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === 'overview'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Project Overview</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('math')}
              className={`px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === 'math'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>Mathematical Formulations</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('architecture')}
              className={`px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === 'architecture'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Software Architecture</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('guide')}
              className={`px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === 'guide'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Student Strategic Guide</span>
            </button>
          </div>

          {/* Body Content */}
          <div className="p-6 overflow-y-auto flex-1 text-xs space-y-6 leading-relaxed">
            {/* 1. Project Overview */}
            {activeSection === 'overview' && (
              <div className="space-y-5">
                <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-5">
                  <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                    <Target className="w-4 h-4 text-emerald-400" />
                    The Problem Space
                  </h4>
                  <p className="text-neutral-300">
                    Conventional academic grade calculators are purely retroactive: they ask students to enter marks they already received and output a static GPA. However, university students face high-stakes forward-looking questions:
                  </p>
                  <ul className="mt-3 space-y-2 text-neutral-300 list-disc list-inside">
                    <li><span className="text-white font-medium">&quot;Can I still make a First Class Honours (or 2:1) if I have 36 credits left?&quot;</span></li>
                    <li><span className="text-white font-medium">&quot;What is the maximum mathematical ceiling for my degree if I make straight A&apos;s from here onwards?&quot;</span></li>
                    <li><span className="text-white font-medium">&quot;How many B&apos;s or C&apos;s can I afford to absorb in difficult elective modules without dropping a degree class?&quot;</span></li>
                  </ul>
                  <p className="text-neutral-300 mt-3">
                    <strong>CGPAMatrix</strong> was designed to answer these questions with mathematical certainty.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-neutral-950/50 border border-neutral-800 rounded-xl p-4">
                    <div className="text-emerald-400 font-bold text-sm mb-1">1. Reverse Deficit Engine</div>
                    <p className="text-neutral-400">
                      Calculates the exact total quality points needed to bridge the gap between your current standing and graduation targets.
                    </p>
                  </div>
                  <div className="bg-neutral-950/50 border border-neutral-800 rounded-xl p-4">
                    <div className="text-cyan-400 font-bold text-sm mb-1">2. Grade Combinatorics</div>
                    <p className="text-neutral-400">
                      Solves unit-weighted integer combinations to output clear &quot;recipes&quot; (e.g. 4 A&apos;s, 2 B&apos;s) rather than abstract percentages.
                    </p>
                  </div>
                  <div className="bg-neutral-950/50 border border-neutral-800 rounded-xl p-4">
                    <div className="text-amber-400 font-bold text-sm mb-1">3. Stress-Test Sandbox</div>
                    <p className="text-neutral-400">
                      Simulates grade volatility and grade drops to test how sensitive your final class of degree is to unexpected exam marks.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* 2. Mathematical Formulations */}
            {activeSection === 'math' && (
              <div className="space-y-5 font-mono">
                <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-5 space-y-4">
                  <h4 className="text-sm font-bold text-emerald-400 font-sans flex items-center gap-2">
                    <Calculator className="w-4 h-4" />
                    Core Mathematical Equations
                  </h4>

                  <div className="space-y-3 font-mono text-[11px]">
                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                      <div className="text-neutral-400 uppercase text-[10px] font-bold">1. Cumulative Quality Points (QP)</div>
                      <div className="text-white text-xs mt-1">QP_current = CGPA_current × Units_completed</div>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                      <div className="text-neutral-400 uppercase text-[10px] font-bold">2. Target Quality Point Deficit</div>
                      <div className="text-white text-xs mt-1">QP_target = CGPA_target × (Units_completed + Units_remaining)</div>
                      <div className="text-emerald-400 text-xs mt-0.5">QP_needed = max(0, QP_target - QP_current)</div>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                      <div className="text-neutral-400 uppercase text-[10px] font-bold">3. Minimum Required GPA for Remaining Credits</div>
                      <div className="text-white text-xs mt-1">GPA_required = QP_needed ÷ Units_remaining</div>
                    </div>

                    <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                      <div className="text-neutral-400 uppercase text-[10px] font-bold">4. Theoretical Maximum Graduating Ceiling</div>
                      <div className="text-cyan-300 text-xs mt-1">
                        CGPA_max = [QP_current + (Scale_max × Units_remaining)] ÷ (Units_completed + Units_remaining)
                      </div>
                      <div className="text-neutral-400 text-[10px] mt-1">
                        Where Scale_max = 5.0 (Nigerian/UK standard) or 4.0 (US/Global standard).
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-5 font-sans">
                  <h4 className="text-sm font-bold text-white mb-2">Grade Recipe Linear Diophantine Decomposition</h4>
                  <p className="text-neutral-300 text-xs leading-relaxed">
                    Given <code className="text-emerald-400 bg-neutral-900 px-1 py-0.5 rounded">Units_remaining</code> and required points <code className="text-emerald-400 bg-neutral-900 px-1 py-0.5 rounded">QP_needed</code>, GradeCraft solves the integer partition:
                  </p>
                  <p className="font-mono text-xs text-white bg-neutral-900 p-2.5 rounded-lg border border-neutral-800 my-2">
                    5 &times; u_A + 4 &times; u_B + 3 &times; u_C &ge; QP_needed, subject to u_A + u_B + u_C = Units_remaining
                  </p>
                  <p className="text-neutral-400 text-xs">
                    This provides actionable course distributions so students can target specific subject weights rather than generic percentages.
                  </p>
                </div>
              </div>
            )}

            {/* 3. Software Architecture */}
            {activeSection === 'architecture' && (
              <div className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-5">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2">
                      <Layers className="w-4 h-4" />
                      Client-Side Reactive Pipeline
                    </div>
                    <p className="text-neutral-300 text-xs leading-relaxed">
                      GradeCraft is engineered with a unidirectional reactive data flow. Inputs update atomic parameters, which trigger the algorithmic engine without round-trip network latency.
                    </p>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      <span className="px-2 py-0.5 bg-neutral-900 border border-neutral-800 text-neutral-300 rounded text-[10px] font-mono">React 18</span>
                      <span className="px-2 py-0.5 bg-neutral-900 border border-neutral-800 text-neutral-300 rounded text-[10px] font-mono">TypeScript 5</span>
                      <span className="px-2 py-0.5 bg-neutral-900 border border-neutral-800 text-neutral-300 rounded text-[10px] font-mono">Tailwind CSS</span>
                      <span className="px-2 py-0.5 bg-neutral-900 border border-neutral-800 text-neutral-300 rounded text-[10px] font-mono">Motion Animations</span>
                    </div>
                  </div>

                  <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-5">
                    <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm mb-2">
                      <ShieldCheck className="w-4 h-4" />
                      Zero-Knowledge Student Privacy
                    </div>
                    <p className="text-neutral-300 text-xs leading-relaxed">
                      Academic records are deeply sensitive personal data. GradeCraft persists state exclusively within the client&apos;s browser sandbox (<code className="text-neutral-200">localStorage</code> / <code className="text-neutral-200">IndexedDB</code>). No analytics or database tracking is collected.
                    </p>
                  </div>
                </div>

                <div className="bg-neutral-950/80 border border-neutral-800 rounded-2xl p-5">
                  <h4 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-emerald-400" />
                    Engineering Highlights
                  </h4>
                  <ul className="space-y-2 text-neutral-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>High-Precision Floating-Point Normalization:</strong> Mitigates IEEE-754 floating-point rounding quirks when summing credit units and weighted grade averages.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Dynamic Multi-Grading Scales:</strong> Supports both 5.0 (First Class, 2:1, 2:2) and 4.0 (Summa / Magna / Cum Laude) standards with accurate grade thresholds.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Live Stress-Test Sandbox:</strong> Allows continuous scrubbing across future GPAs to verify degree resilience against exam volatility.</span>
                    </li>
                  </ul>
                </div>
              </div>
            )}

            {/* 4. Student Guide */}
            {activeSection === 'guide' && (
              <div className="space-y-5">
                <div className="bg-neutral-950/60 border border-neutral-800 rounded-2xl p-5 space-y-3">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-emerald-400" />
                    How to Strategize Your Academics with CGPAMatrix
                  </h4>
                  <p className="text-neutral-300 leading-relaxed">
                    Follow this three-step blueprint each semester to stay in full control of your graduating degree classification:
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 flex flex-col justify-between">
                    <div>
                      <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs mb-2">1</span>
                      <h5 className="font-bold text-white text-xs mb-1">Check Your Ceiling First</h5>
                      <p className="text-neutral-400 text-[11px] leading-relaxed">
                        Input your current CGPA and completed units. Look at the <strong className="text-cyan-400">Max Possible CGPA</strong>. If your target is above this number, adjust your target realistically.
                      </p>
                    </div>
                  </div>

                  <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 flex flex-col justify-between">
                    <div>
                      <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs mb-2">2</span>
                      <h5 className="font-bold text-white text-xs mb-1">Prioritize High-Credit Courses</h5>
                      <p className="text-neutral-400 text-[11px] leading-relaxed">
                        In Tab 2 (Coursework), notice that a 4-unit course contributes 20 quality points for an A, whereas a 1-unit course only contributes 5 points. Focus your revision where points multiply fastest.
                      </p>
                    </div>
                  </div>

                  <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 flex flex-col justify-between">
                    <div>
                      <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-xs mb-2">3</span>
                      <h5 className="font-bold text-white text-xs mb-1">Simulate the Worst Case</h5>
                      <p className="text-neutral-400 text-[11px] leading-relaxed">
                        In Tab 3 (&quot;What-If&quot; Sandbox), drag the slider to 3.50 or 3.00. Check if a difficult semester would drop your overall class of degree, allowing you to prepare backup study plans in advance.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer Action */}
          <div className="px-6 py-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
            <span className="text-[11px] text-neutral-500">
              CGPAMatrix &bull; Engineered by Otitologbon Oluwabunmi (IT Specialist &amp; Frontend Engineer)
            </span>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors cursor-pointer"
            >
              Close Guide &amp; Return to Simulator
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
