import React from 'react';
import { GradeCraftApp } from './components/gradecraft/GradeCraftApp';

export default function App() {
  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col selection:bg-emerald-500 selection:text-white">
      <GradeCraftApp />
    </div>
  );
}
