import {
  GradingScaleType,
  GradeDefinition,
  DegreeClassification,
  Course,
  GradeRecipe,
  SimulationResult,
} from '../types/gradecraft';

export const GRADES_5_0: GradeDefinition[] = [
  { letter: 'A', points: 5.0, description: 'Excellent (70-100%)', minScore: 70 },
  { letter: 'B', points: 4.0, description: 'Very Good (60-69%)', minScore: 60 },
  { letter: 'C', points: 3.0, description: 'Good (50-59%)', minScore: 50 },
  { letter: 'D', points: 2.0, description: 'Fair (45-49%)', minScore: 45 },
  { letter: 'E', points: 1.0, description: 'Pass (40-44%)', minScore: 40 },
  { letter: 'F', points: 0.0, description: 'Fail (0-39%)', minScore: 0 },
];

export const GRADES_4_0: GradeDefinition[] = [
  { letter: 'A', points: 4.0, description: 'Excellent (90-100%)', minScore: 90 },
  { letter: 'B', points: 3.0, description: 'Good (80-89%)', minScore: 80 },
  { letter: 'C', points: 2.0, description: 'Average (70-79%)', minScore: 70 },
  { letter: 'D', points: 1.0, description: 'Passing (60-69%)', minScore: 60 },
  { letter: 'F', points: 0.0, description: 'Failing (0-59%)', minScore: 0 },
];

export const CLASSIFICATIONS_5_0: DegreeClassification[] = [
  { label: 'First Class Honours', minCgpa: 4.50, maxCgpa: 5.00, badgeColor: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400', textColor: 'text-emerald-400' },
  { label: 'Second Class Upper (2:1)', minCgpa: 3.50, maxCgpa: 4.49, badgeColor: 'bg-blue-500/10 border-blue-500/30 text-blue-400', textColor: 'text-blue-400' },
  { label: 'Second Class Lower (2:2)', minCgpa: 2.40, maxCgpa: 3.49, badgeColor: 'bg-amber-500/10 border-amber-500/30 text-amber-400', textColor: 'text-amber-400' },
  { label: 'Third Class', minCgpa: 1.50, maxCgpa: 2.39, badgeColor: 'bg-orange-500/10 border-orange-500/30 text-orange-400', textColor: 'text-orange-400' },
  { label: 'Pass', minCgpa: 1.00, maxCgpa: 1.49, badgeColor: 'bg-neutral-500/10 border-neutral-500/30 text-neutral-400', textColor: 'text-neutral-400' },
];

export const CLASSIFICATIONS_4_0: DegreeClassification[] = [
  { label: 'Summa Cum Laude / High Distinction', minCgpa: 3.80, maxCgpa: 4.00, badgeColor: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400', textColor: 'text-emerald-400' },
  { label: 'Magna Cum Laude / Distinction', minCgpa: 3.50, maxCgpa: 3.79, badgeColor: 'bg-blue-500/10 border-blue-500/30 text-blue-400', textColor: 'text-blue-400' },
  { label: 'Cum Laude / Honours', minCgpa: 3.00, maxCgpa: 3.49, badgeColor: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400', textColor: 'text-cyan-400' },
  { label: 'Good Standing', minCgpa: 2.00, maxCgpa: 2.99, badgeColor: 'bg-amber-500/10 border-amber-500/30 text-amber-400', textColor: 'text-amber-400' },
  { label: 'Academic Warning', minCgpa: 0.00, maxCgpa: 1.99, badgeColor: 'bg-rose-500/10 border-rose-500/30 text-rose-400', textColor: 'text-rose-400' },
];

export function getGradePoint(letter: string, scale: GradingScaleType): number {
  const grades = scale === '5.0' ? GRADES_5_0 : GRADES_4_0;
  const match = grades.find((g) => g.letter.toUpperCase() === letter.toUpperCase());
  return match ? match.points : 0;
}

export function getClassification(cgpa: number, scale: GradingScaleType): DegreeClassification {
  const classes = scale === '5.0' ? CLASSIFICATIONS_5_0 : CLASSIFICATIONS_4_0;
  const match = classes.find((c) => cgpa >= c.minCgpa && cgpa <= c.maxCgpa);
  if (match) return match;
  return classes[classes.length - 1];
}

export function calculateSemesterGPA(courses: Course[], scale: GradingScaleType): { gpa: number; totalUnits: number; totalPoints: number } {
  let totalUnits = 0;
  let totalPoints = 0;

  for (const c of courses) {
    const units = Number(c.units) || 0;
    const points = getGradePoint(c.grade, scale);
    totalUnits += units;
    totalPoints += units * points;
  }

  const gpa = totalUnits > 0 ? Number((totalPoints / totalUnits).toFixed(2)) : 0;
  return { gpa, totalUnits, totalPoints };
}

/**
 * Reverse Target Forecaster Calculation
 */
export function simulateTargetGoal(
  currentCgpa: number,
  completedUnits: number,
  targetCgpa: number,
  remainingUnits: number,
  scale: GradingScaleType
): SimulationResult {
  const maxScalePoint = scale === '5.0' ? 5.0 : 4.0;
  const totalUnitsOverall = Math.max(1, completedUnits + remainingUnits);
  const currentTotalPoints = currentCgpa * completedUnits;

  // Max and Min possible
  const maxPointsOverall = currentTotalPoints + (maxScalePoint * remainingUnits);
  const maxPossibleCgpa = Number((maxPointsOverall / totalUnitsOverall).toFixed(2));

  const minPointsOverall = currentTotalPoints + (0.0 * remainingUnits);
  const minPossibleCgpa = Number((minPointsOverall / totalUnitsOverall).toFixed(2));

  // Needed
  const neededOverallPoints = targetCgpa * totalUnitsOverall;
  const neededRemainingPoints = Math.max(0, neededOverallPoints - currentTotalPoints);
  const requiredGpa = remainingUnits > 0 ? Number((neededRemainingPoints / remainingUnits).toFixed(2)) : 0;

  const isFeasible = requiredGpa <= maxScalePoint && maxPossibleCgpa >= targetCgpa;

  const currentClassification = getClassification(currentCgpa, scale).label;
  const targetClassification = getClassification(targetCgpa, scale).label;

  // Generate grade recipes
  const recipes: GradeRecipe[] = [];

  if (remainingUnits > 0) {
    const avgUnitsPerCourse = 3;
    const approxCourses = Math.max(1, Math.round(remainingUnits / avgUnitsPerCourse));

    if (!isFeasible) {
      // Unfeasible recipe showing ceiling
      recipes.push({
        title: 'Maximum Possible Effort (All A\'s)',
        description: `Even with straight A's in all remaining ${remainingUnits} credit units, your graduating ceiling is ${maxPossibleCgpa.toFixed(2)}.`,
        recipeType: 'optimum',
        projectedSemesterGpa: maxScalePoint,
        projectedFinalCgpa: maxPossibleCgpa,
        feasibility: 'impossible',
        breakdown: [
          {
            letter: 'A',
            points: maxScalePoint,
            units: remainingUnits,
            courseCountApprox: approxCourses,
          },
        ],
      });
    } else {
      // Recipe 1: Optimum (Straight A focus)
      if (scale === '5.0') {
        // Find split between A (5) and B (4) or C (3)
        // requiredPoints = 5*aUnits + 4*bUnits, where aUnits + bUnits = remainingUnits
        // 5*a + 4*(remaining - a) >= neededRemainingPoints
        // a >= neededRemainingPoints - 4*remaining
        let aUnits = Math.ceil(neededRemainingPoints - 4 * remainingUnits);
        aUnits = Math.max(0, Math.min(remainingUnits, aUnits));
        let bUnits = remainingUnits - aUnits;

        const gpa1 = (aUnits * 5 + bUnits * 4) / remainingUnits;
        const finalCgpa1 = (currentTotalPoints + (aUnits * 5 + bUnits * 4)) / totalUnitsOverall;

        recipes.push({
          title: 'Prime Path (A & B Mastery)',
          description: `Score primarily A's with a cushion of B's across your remaining units.`,
          recipeType: 'optimum',
          projectedSemesterGpa: Number(gpa1.toFixed(2)),
          projectedFinalCgpa: Number(finalCgpa1.toFixed(2)),
          feasibility: requiredGpa > 4.6 ? 'challenging' : 'easily_achievable',
          breakdown: [
            { letter: 'A', points: 5, units: aUnits, courseCountApprox: Math.round((aUnits / remainingUnits) * approxCourses) },
            ...(bUnits > 0 ? [{ letter: 'B', points: 4, units: bUnits, courseCountApprox: Math.round((bUnits / remainingUnits) * approxCourses) }] : []),
          ],
        });

        // Recipe 2: Balanced (Mix of A, B, C if requiredGpa is moderate)
        if (requiredGpa <= 4.0) {
          // Can afford C's
          const cUnits = Math.floor(remainingUnits * 0.25);
          const remUnits = remainingUnits - cUnits;
          const neededAfterC = neededRemainingPoints - (cUnits * 3);
          let balA = Math.ceil(neededAfterC - 4 * remUnits);
          balA = Math.max(0, Math.min(remUnits, balA));
          let balB = remUnits - balA;

          const gpa2 = (balA * 5 + balB * 4 + cUnits * 3) / remainingUnits;
          const finalCgpa2 = (currentTotalPoints + (balA * 5 + balB * 4 + cUnits * 3)) / totalUnitsOverall;

          recipes.push({
            title: 'Balanced Path (Room for 1-2 C\'s)',
            description: `A flexible distribution that absorbs tougher elective courses while keeping your target locked.`,
            recipeType: 'balanced',
            projectedSemesterGpa: Number(gpa2.toFixed(2)),
            projectedFinalCgpa: Number(finalCgpa2.toFixed(2)),
            feasibility: 'moderate',
            breakdown: [
              ...(balA > 0 ? [{ letter: 'A', points: 5, units: balA, courseCountApprox: Math.round((balA / remainingUnits) * approxCourses) }] : []),
              ...(balB > 0 ? [{ letter: 'B', points: 4, units: balB, courseCountApprox: Math.round((balB / remainingUnits) * approxCourses) }] : []),
              { letter: 'C', points: 3, units: cUnits, courseCountApprox: Math.max(1, Math.round((cUnits / remainingUnits) * approxCourses)) },
            ],
          });
        }
      } else {
        // 4.0 Scale recipes
        let aUnits = Math.ceil(neededRemainingPoints - 3 * remainingUnits);
        aUnits = Math.max(0, Math.min(remainingUnits, aUnits));
        let bUnits = remainingUnits - aUnits;

        const gpa = (aUnits * 4 + bUnits * 3) / remainingUnits;
        const finalCgpa = (currentTotalPoints + (aUnits * 4 + bUnits * 3)) / totalUnitsOverall;

        recipes.push({
          title: 'Target Honors Path',
          description: `Focus on high grades in core courses to secure your GPA requirement.`,
          recipeType: 'optimum',
          projectedSemesterGpa: Number(gpa.toFixed(2)),
          projectedFinalCgpa: Number(finalCgpa.toFixed(2)),
          feasibility: requiredGpa > 3.6 ? 'challenging' : 'easily_achievable',
          breakdown: [
            { letter: 'A', points: 4, units: aUnits, courseCountApprox: Math.round((aUnits / remainingUnits) * approxCourses) },
            ...(bUnits > 0 ? [{ letter: 'B', points: 3, units: bUnits, courseCountApprox: Math.round((bUnits / remainingUnits) * approxCourses) }] : []),
          ],
        });
      }
    }
  }

  return {
    maxPossibleCgpa,
    minPossibleCgpa,
    isFeasible,
    requiredGpaForRemaining: Math.min(maxScalePoint, requiredGpa),
    totalUnitsOverall,
    currentTotalQualityPoints: currentTotalPoints,
    targetClassification,
    currentClassification,
    recipes,
  };
}

export const SAMPLE_SEMESTERS: Course[] = [
  { id: '1', code: 'CSC 301', title: 'Data Structures & Algorithms', units: 3, grade: 'A' },
  { id: '2', code: 'CSC 305', title: 'Operating Systems Architecture', units: 3, grade: 'B' },
  { id: '3', code: 'CSC 309', title: 'Database Management Systems', units: 3, grade: 'A' },
  { id: '4', code: 'MTH 311', title: 'Numerical Analysis & Computation', units: 2, grade: 'B' },
  { id: '5', code: 'CSC 315', title: 'Software Engineering Methodologies', units: 3, grade: 'A' },
  { id: '6', code: 'GST 301', title: 'Entrepreneurship & Innovation', units: 2, grade: 'A' },
  { id: '7', code: 'CSC 317', title: 'Computer Networks & Security', units: 3, grade: 'B' },
];
