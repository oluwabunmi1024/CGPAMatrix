# CGPAMatrix — Predictive CGPA Simulator & Target Degree Planner

> **Academic performance modeling and target degree engineering software.**  
> Solves the **Reverse Target Deficit Problem** by calculating the exact minimum combination of grades needed across remaining credit units to graduate with your desired honours class.

---

## 🎯 The Problem Solved
Traditional grade calculators only record **past** marks to show a historical GPA. University students, however, face high-stakes forward-looking questions:
- *"Can I still finish with First Class Honours if I have 36 credit units left?"*
- *"What is my absolute mathematical ceiling if I earn straight A's from here on?"*
- *"How many B's or C's can I afford to absorb without losing my 2:1 degree classification?"*

**CGPAMatrix** provides mathematically guaranteed answers and concrete grade distributions (e.g. *4 A's and 2 B's*) rather than abstract percentages.

---

## ✨ Features
- **Reverse Target Deficit Forecaster**: Enter your current CGPA, completed units, and desired graduating CGPA. Get instant feasibility analysis, required semester GPA, and concrete grade recipes.
- **Graduating Ceiling Detection**: Calculates the highest possible CGPA theoretically attainable even with straight A's, saving students from false assumptions.
- **Dual Grading Scale Standards**:
  - **5.0 Scale** (Standard Nigerian / UK Honours: First Class, 2:1, 2:2, Third Class)
  - **4.0 Scale** (US / Global Honours: Summa Cum Laude, Magna Cum Laude, Cum Laude)
- **Interactive Coursework Matrix**: Add current semester courses and test grades with real-time Quality Points, Semester GPA, and cumulative CGPA updates.
- **"What-If" Stress-Test Sandbox**: Scrub future GPA scenarios to analyze the sensitivity of your final classification to unexpected exam marks.
- **100% Client-Side Privacy**: Runs completely offline and persists data strictly in browser `localStorage`. No analytics, telemetry, or external databases.

---

## 🧮 Mathematical Formulation

### 1. Cumulative Quality Points ($QP$)
$$QP_{\text{current}} = \text{CGPA}_{\text{current}} \times \text{Units}_{\text{completed}}$$

### 2. Target Quality Point Deficit
$$QP_{\text{target}} = \text{CGPA}_{\text{target}} \times (\text{Units}_{\text{completed}} + \text{Units}_{\text{remaining}})$$
$$QP_{\text{needed}} = \max(0, QP_{\text{target}} - QP_{\text{current}})$$

### 3. Required GPA for Remaining Credits
$$\text{GPA}_{\text{required}} = \frac{QP_{\text{needed}}}{\text{Units}_{\text{remaining}}}$$

### 4. Theoretical Maximum Graduating Ceiling
$$\text{CGPA}_{\text{max}} = \frac{QP_{\text{current}} + (\text{Scale}_{\text{max}} \times \text{Units}_{\text{remaining}})}{\text{Units}_{\text{completed}} + \text{Units}_{\text{remaining}}}$$

---

## 🛠 Tech Stack
- **Framework**: [React 18](https://react.dev/) + [Vite](https://vitejs.dev/)
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Animations**: [Motion](https://motion.dev/)

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation
```bash
# Clone repository
git clone https://github.com/your-username/cgpamatrix.git

# Navigate into directory
cd cgpamatrix

# Install dependencies
npm install

# Start local dev server
npm run dev
```

### Build for Production
```bash
npm run build
```

---

## 👤 Author
**Otitologbon Oluwabunmi**  
- Portfolio / GitHub: [@botitologbon](https://github.com/botitologbon)
- IT Specialist & Frontend Developer
